# Smart Electricity Theft Detection System (simulated data)

C backend (HTTP server + SQLite) + HTML/CSS/JS frontend. Login: **admin / admin123**.

## Windows 11 setup
1. Install MinGW-w64 (e.g. MSYS2 -> `pacman -S mingw-w64-ucrt-x86_64-gcc`) and add its `bin` folder to PATH. Check: `gcc --version`
2. Download the SQLite **amalgamation** zip from https://www.sqlite.org/download.html (sqlite-amalgamation-xxxx.zip).
   Copy `sqlite3.c` and `sqlite3.h` into the `backend` folder.
3. Open VS Code terminal in the project folder:
```
cd backend
gcc main.c detection.c sqlite3.c -o server.exe -lws2_32
server.exe
```
4. Open http://localhost:8080 in Chrome/Edge. (Always run `server.exe` from inside `backend`.)
The database (`database/theft.db`) is created from `database/schema.sql` automatically, with 10 sample meters.

## Test checklist
- Login with wrong password (error) and correct password.
- Dashboard: cards, monthly graph, recent alerts.
- Meters: add meter (prev 100, curr 250), search, status filter, History button.
- Detection: change threshold, Run detection, Generate new simulated readings, Reset sample data.
- Alerts: change alert/inspection status (saved). Reports: 3 CSV downloads. Logout.

## Detection rules (backend/detection.c)
Missing reading, reading lower than previous, zero use vs. history, drop below threshold (default 40%), spike above 2x threshold.
Results are indicators on simulated data, not proof of theft; flagged meters need human inspection.
Note: passwords are stored in plain text for simplicity (college demo only).
