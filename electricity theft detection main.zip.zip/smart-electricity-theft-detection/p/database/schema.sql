CREATE TABLE IF NOT EXISTS admin(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT);
CREATE TABLE IF NOT EXISTS meters(meter_id TEXT PRIMARY KEY, consumer_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY, meter_id TEXT, read_date TEXT, reading REAL);
CREATE TABLE IF NOT EXISTS detections(id INTEGER PRIMARY KEY, meter_id TEXT, consumer_id TEXT, prev_reading REAL, curr_reading REAL, consumption REAL, hist_avg REAL, status TEXT, reason TEXT, detected_on TEXT);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, meter_id TEXT, alert_date TEXT, reason TEXT, status TEXT DEFAULT 'Open', inspection TEXT DEFAULT 'Pending');
INSERT OR IGNORE INTO admin(username,password) VALUES('admin','admin123');
