const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function api(p,body){const o=body?{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body)}:{};
 const r=await fetch(p,o);if(r.status==401&&p!='/api/login'){showLogin();throw 0}return r.json()}
const tag=s=>`<span class="tag ${s.replace(' ','')}">${esc(s)}</span>`,num=v=>v<0?'<i>missing</i>':v;
function showLogin(){$('#login').hidden=false;$('#app').hidden=true}
async function doLogin(e){e.preventDefault();const r=await api('/api/login',{user:$('#u').value,pass:$('#p').value});
 if(r.error){$('#lerr').textContent=r.error;return false}$('#login').hidden=true;$('#app').hidden=false;go('dashboard');return false}
async function logout(){await api('/api/logout',{});showLogin()}
document.querySelectorAll('aside a[data-v]').forEach(a=>a.onclick=()=>go(a.dataset.v));
function go(v){document.querySelectorAll('aside a').forEach(a=>a.classList.toggle('on',a.dataset.v==v));views[v]()}
const views={
async dashboard(){const[s]=await api('/api/stats'),ch=await api('/api/chart'),al=await api('/api/alerts'),mx=Math.max(...ch.map(c=>c.kwh),1);
 $('#main').innerHTML=`<h1 class=t>Dashboard</h1><div class=cards><div class=card><b>${s.total}</b><span>Total meters</span></div><div class=card><b>${s.normal}</b><span>Normal connections</span></div>
 <div class=card><b style="color:#dc2626">${s.suspicious}</b><span>Suspicious / needs inspection</span></div><div class=card><b>${Math.round(s.consumption)}</b><span>Latest consumption (kWh)</span></div></div>
 <div class=panel><h3>Electricity consumption by month (kWh, all meters)</h3><div class=chart>${ch.map(c=>`<div>${Math.round(c.kwh)}<i style="height:${c.kwh/mx*120}px"></i>${c.month}</div>`).join('')}</div></div>
 <div class=panel><h3>Recent alerts</h3><table><tr><th>Meter</th><th>Date</th><th>Reason</th><th>Status</th></tr>${al.slice(0,5).map(a=>`<tr><td>${esc(a.meter_id)}</td><td>${a.alert_date}</td><td>${esc(a.reason)}</td><td>${esc(a.status)}</td></tr>`).join('')||'<tr><td colspan=4>No alerts</td></tr>'}</table></div>`},
async meters(){$('#main').innerHTML=`<h1 class=t>Meter Management</h1><div class=panel><h3>Add meter / new reading</h3><div class=form>
 <input id=mm placeholder="Meter ID"><input id=mc placeholder="Consumer ID"><input id=mp type=number min=0 placeholder="Previous reading"><input id=mu type=number min=0 placeholder="Current reading">
 <button class=btn onclick=addMeter()>Save</button></div><div class=err id=me></div><small>Consumption = current − previous. An existing Meter ID just receives the new current reading.</small></div>
 <div class=panel><div class=form><input id=q placeholder="Search meter / consumer" oninput=listMeters()><select id=f onchange=listMeters()><option value="">All status<option>Normal<option>Suspicious<option>Needs Inspection</select></div><div id=ml></div><div id=hist></div></div>`;listMeters()},
async detection(){const t=await api('/api/threshold'),d=await api('/api/detections');
 $('#main').innerHTML=`<h1 class=t>Theft Detection</h1><div class=note>Results are <b>indicators from simulated data, not proof of theft</b>. Flagged meters require human inspection.</div>
 <div class=panel><div class=form>Deviation threshold (%): <input id=th type=number value=${t.threshold} style="width:90px"><button class=btn onclick=runDet()>Run detection</button>
 <button class="btn g" onclick=gen()>Generate new simulated readings</button><button class="btn g" onclick=reset()>Reset sample data</button></div><div class=err id=de></div>
 <table><tr><th>Meter</th><th>Prev</th><th>Curr</th><th>Consumption</th><th>Hist. avg</th><th>Status</th><th>Why</th></tr>${d.map(r=>`<tr><td>${esc(r.meter_id)}</td><td>${num(r.prev_reading)}</td><td>${num(r.curr_reading)}</td><td>${r.consumption}</td><td>${r.hist_avg}</td><td>${tag(r.status)}</td><td>${esc(r.reason)}</td></tr>`).join('')}</table></div>`},
async alerts(){const a=await api('/api/alerts'),o=(l,v)=>l.map(x=>`<option ${x==v?'selected':''}>${x}`).join('');
 $('#main').innerHTML=`<h1 class=t>Alerts &amp; Notifications</h1><div class=panel><table><tr><th>Meter</th><th>Date</th><th>Reason</th><th>Alert status</th><th>Inspection</th></tr>${a.map(x=>`<tr><td>${esc(x.meter_id)}</td><td>${x.alert_date}</td><td>${esc(x.reason)}</td>
 <td><select id=s${x.id} onchange=upd(${x.id})>${o(['Open','Under Review','Resolved'],x.status)}</select></td><td><select id=i${x.id} onchange=upd(${x.id})>${o(['Pending','Scheduled','Completed'],x.inspection)}</select></td></tr>`).join('')||'<tr><td colspan=5>No alerts</td></tr>'}</table></div>`},
reports(){$('#main').innerHTML=`<h1 class=t>Reports</h1><div class=panel><p>Download CSV reports:</p><div class=form>
 <a class=btn href="/api/report?type=meters">Meter / detection report</a><a class=btn href="/api/report?type=consumption">Consumption history</a><a class=btn href="/api/report?type=alerts">Suspicious activity (alerts)</a></div></div>`}};
async function listMeters(){const m=await api(`/api/meters?q=${encodeURIComponent($('#q').value)}&f=${encodeURIComponent($('#f').value)}`);
 $('#ml').innerHTML=`<table><tr><th>Meter</th><th>Consumer</th><th>Prev</th><th>Curr</th><th>Consumption</th><th>Status</th><th></th></tr>${m.map(r=>`<tr><td>${esc(r.meter_id)}</td><td>${esc(r.consumer_id)}</td><td>${num(r.prev_reading)}</td><td>${num(r.curr_reading)}</td><td>${r.consumption??''}</td><td>${tag(r.status||'Normal')}</td><td><button class="btn g" onclick="hist('${esc(r.meter_id)}')">History</button></td></tr>`).join('')}</table>`}
async function hist(id){const h=await api('/api/history?meter='+encodeURIComponent(id)),v=h.filter(x=>x.reading>=0),mx=Math.max(...v.map(x=>x.reading),1);
 $('#hist').innerHTML=`<h3>Reading history – ${esc(id)}</h3><div class=chart>${h.map(x=>`<div>${x.reading<0?'missing':x.reading}<i style="height:${x.reading<0?2:x.reading/mx*120}px"></i>${x.read_date.slice(2,7)}</div>`).join('')}</div>`}
async function addMeter(){const p={meter:$('#mm').value.trim(),consumer:$('#mc').value.trim(),prev:$('#mp').value,curr:$('#mu').value};
 if(!p.meter||!p.consumer||p.prev===''||p.curr===''){$('#me').textContent='All fields are required.';return}
 if(+p.curr<+p.prev&&!confirm('Current reading is lower than previous. Save anyway (will be flagged)?'))return;
 const r=await api('/api/meters',p);$('#me').textContent=r.error||'';if(!r.error)views.meters()}
async function runDet(){const r=await api('/api/detect',{threshold:$('#th').value});if(r.error)$('#de').textContent=r.error;else views.detection()}
async function gen(){await api('/api/generate',{});views.detection()}
async function reset(){if(confirm('Reset all meters, readings and alerts to sample data?')){await api('/api/reset',{});views.detection()}}
async function upd(id){await api('/api/alert',{id,status:$('#s'+id).value,inspection:$('#i'+id).value})}
api('/api/stats').then(()=>{$('#login').hidden=true;$('#app').hidden=false;go('dashboard')}).catch(()=>{});
