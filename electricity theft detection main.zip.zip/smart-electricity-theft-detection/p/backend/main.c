/* Smart Electricity Theft Detection - C backend: HTTP server + SQLite + API */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include "sqlite3.h"
#include "detection.h"
#ifdef _WIN32
#include <winsock2.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
typedef int SOCKET;
#define closesocket close
#endif
#define PORT 8080
static sqlite3 *db; static double THR = 0.4; static char TOKEN[32] = "";
typedef struct { char *d; size_t n, cap; } Buf;
static void bput(Buf *b, const char *s, size_t k) {
    if (b->n + k + 1 > b->cap) { b->cap = (b->n + k + 1) * 2; b->d = realloc(b->d, b->cap); }
    memcpy(b->d + b->n, s, k); b->n += k; b->d[b->n] = 0;
}
static void bp(Buf *b, const char *f, ...) {
    char t[2048]; va_list a; va_start(a, f); int k = vsnprintf(t, sizeof t, f, a); va_end(a);
    if (k > (int)sizeof t - 1) k = sizeof t - 1; bput(b, t, k);
}
static void bs(Buf *b, const char *s, int csv) {
    bput(b, csv ? "\"" : "\"", 1);
    for (; *s; s++) {
        if (csv) { if (*s == '"') bput(b, "\"\"", 2); else bput(b, s, 1); }
        else if (*s == '"' || *s == '\\') { bput(b, "\\", 1); bput(b, s, 1); }
        else if ((unsigned char)*s < 32) bput(b, " ", 1); else bput(b, s, 1);
    }
    bput(b, "\"", 1);
}
static int param(const char *s, const char *k, char *out, size_t n) {
    out[0] = 0; size_t kl = strlen(k); const char *p = s;
    while (p && *p) {
        if (!strncmp(p, k, kl) && p[kl] == '=') {
            const char *v = p + kl + 1; size_t i = 0;
            while (*v && *v != '&' && i < n - 1) {
                if (*v == '%' && v[1] && v[2]) { char h[3] = {v[1], v[2], 0}; out[i++] = (char)strtol(h, 0, 16); v += 3; }
                else if (*v == '+') { out[i++] = ' '; v++; } else out[i++] = *v++;
            }
            out[i] = 0; return 1;
        }
        p = strchr(p, '&'); if (p) p++;
    }
    return 0;
}
static int xb(const char *sql, int nb, const char **bv) {
    sqlite3_stmt *s; if (sqlite3_prepare_v2(db, sql, -1, &s, 0)) return -1;
    for (int i = 0; i < nb; i++) sqlite3_bind_text(s, i + 1, bv[i], -1, SQLITE_TRANSIENT);
    int rc = sqlite3_step(s); sqlite3_finalize(s); return rc == SQLITE_DONE ? 0 : -1;
}
static void qout(Buf *b, const char *sql, int nb, const char **bv, int csv) {
    sqlite3_stmt *s; if (sqlite3_prepare_v2(db, sql, -1, &s, 0)) { if (!csv) bput(b, "[]", 2); return; }
    for (int i = 0; i < nb; i++) sqlite3_bind_text(s, i + 1, bv[i], -1, SQLITE_TRANSIENT);
    int nc = sqlite3_column_count(s), first = 1;
    if (csv) { for (int c = 0; c < nc; c++) { if (c) bput(b, ",", 1); bs(b, sqlite3_column_name(s, c), 1); } bput(b, "\r\n", 2); }
    else bput(b, "[", 1);
    while (sqlite3_step(s) == SQLITE_ROW) {
        if (!csv) { if (!first) bput(b, ",", 1); first = 0; bput(b, "{", 1); }
        for (int c = 0; c < nc; c++) {
            if (c) bput(b, ",", 1);
            if (!csv) { bs(b, sqlite3_column_name(s, c), 0); bput(b, ":", 1); }
            int t = sqlite3_column_type(s, c);
            if (t == SQLITE_NULL) bput(b, csv ? "" : "null", csv ? 0 : 4);
            else if (t == SQLITE_INTEGER) bp(b, "%lld", sqlite3_column_int64(s, c));
            else if (t == SQLITE_FLOAT) bp(b, "%.2f", sqlite3_column_double(s, c));
            else bs(b, (const char *)sqlite3_column_text(s, c), csv);
        }
        if (csv) bput(b, "\r\n", 2); else bput(b, "}", 1);
    }
    if (!csv) bput(b, "]", 1);
    sqlite3_finalize(s);
}
/* ---- Module 1: data collection ---- */
static void addreading(const char *id, int off, double v) {
    char sql[256]; snprintf(sql, sizeof sql, "INSERT INTO readings(meter_id,read_date,reading) VALUES('%s',date('now','%+d month'),%.2f)", id, off, v);
    sqlite3_exec(db, sql, 0, 0, 0);
}
static void seed(int reset) {
    if (reset) sqlite3_exec(db, "DELETE FROM readings;DELETE FROM meters;DELETE FROM alerts;DELETE FROM detections;", 0, 0, 0);
    srand((unsigned)time(0));
    for (int i = 0; i < 10; i++) {
        char id[16], cid[16]; sprintf(id, "M%04d", 1001 + i); sprintf(cid, "C%03d", 201 + i);
        const char *b[2] = {id, cid}; xb("INSERT OR IGNORE INTO meters VALUES(?1,?2)", 2, b);
        double base = 200 + (i * 37) % 150, cum = 1000 + i * 500;
        for (int j = 0; j < 7; j++) {
            double s = base * (0.9 + (rand() % 21) / 100.0);
            if (j == 6) { if (i == 3) s = base * 0.3; else if (i == 6) s = 0; else if (i == 9) s = base * 2.6; }
            if (j > 0) cum += s;
            double val = cum;
            if (j == 6 && i == 4) val = -1;
            if (j == 6 && i == 7) val = cum - base * 1.5;
            addreading(id, j - 6, val);
        }
    }
}
static void generate_new(void) {
    sqlite3_stmt *m; sqlite3_prepare_v2(db, "SELECT m.meter_id,(SELECT MAX(reading) FROM readings r WHERE r.meter_id=m.meter_id),(SELECT COUNT(*) FROM readings r WHERE r.meter_id=m.meter_id) FROM meters m", -1, &m, 0);
    char ids[200][32]; double mx[200]; int cn[200], k = 0;
    while (sqlite3_step(m) == SQLITE_ROW && k < 200) { snprintf(ids[k], 32, "%s", sqlite3_column_text(m, 0)); mx[k] = sqlite3_column_double(m, 1); cn[k] = sqlite3_column_int(m, 2); k++; }
    sqlite3_finalize(m);
    for (int i = 0; i < k; i++) {
        double base = 200 + atoi(ids[i] + 1) % 150, f = 0.9 + (rand() % 21) / 100.0; int e = rand() % 100;
        double v = mx[i] + base * f;
        if (e < 8) v = mx[i] + base * 0.3; else if (e < 13) v = mx[i]; else if (e < 17) v = -1; else if (e < 21) v = mx[i] + base * 2.6;
        addreading(ids[i], cn[i] - 6, v);
    }
}
/* ---- Module 2: detection (uses C analyze()) ---- */
static void run_detection(void) {
    sqlite3_exec(db, "DELETE FROM detections", 0, 0, 0);
    sqlite3_stmt *m; sqlite3_prepare_v2(db, "SELECT meter_id,consumer_id FROM meters", -1, &m, 0);
    while (sqlite3_step(m) == SQLITE_ROW) {
        char id[64], cid[64]; snprintf(id, 64, "%s", sqlite3_column_text(m, 0)); snprintf(cid, 64, "%s", sqlite3_column_text(m, 1));
        double r[256]; int k = 0; sqlite3_stmt *q;
        sqlite3_prepare_v2(db, "SELECT reading FROM readings WHERE meter_id=?1 ORDER BY id", -1, &q, 0);
        sqlite3_bind_text(q, 1, id, -1, SQLITE_TRANSIENT);
        while (sqlite3_step(q) == SQLITE_ROW && k < 256) r[k++] = sqlite3_column_double(q, 0);
        sqlite3_finalize(q); if (!k) continue;
        double curr = r[k - 1], prev = -1; int pi = -1;
        for (int i = k - 2; i >= 0; i--) if (r[i] >= 0) { prev = r[i]; pi = i; break; }
        double h[256]; int n = 0; double last = -1;
        for (int i = 0; i <= pi; i++) if (r[i] >= 0) { if (last >= 0 && r[i] >= last) h[n++] = r[i] - last; last = r[i]; }
        Result res; analyze(prev, curr, h, n, THR, &res);
        char a[32], b2[32], c[32], d[32]; sprintf(a, "%.2f", prev); sprintf(b2, "%.2f", curr); sprintf(c, "%.2f", res.cons); sprintf(d, "%.2f", res.avg);
        const char *bv[9] = {id, cid, a, b2, c, d, res.status, res.reason};
        xb("INSERT INTO detections(meter_id,consumer_id,prev_reading,curr_reading,consumption,hist_avg,status,reason,detected_on) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,date('now'))", 8, bv);
        if (strcmp(res.status, "Normal")) {
            const char *ab[2] = {id, res.reason};
            xb("INSERT INTO alerts(meter_id,alert_date,reason) SELECT ?1,date('now'),?2 WHERE NOT EXISTS(SELECT 1 FROM alerts WHERE meter_id=?1 AND status!='Resolved' AND reason=?2)", 2, ab);
        }
    }
    sqlite3_finalize(m);
}
/* ---- API (Module 3 alerts/reports included) ---- */
static int api(const char *meth, const char *path, const char *qs, const char *body, Buf *o, const char **ct, char *extra, int authed) {
    char a[128], b[128], c[128], d[128]; *ct = "application/json";
    if (!strcmp(path, "/api/login")) {
        param(body, "user", a, 128); param(body, "pass", b, 128);
        const char *bv[2] = {a, b}; Buf t = {0}; qout(&t, "SELECT 1 x FROM admin WHERE username=?1 AND password=?2", 2, bv, 0);
        int ok = t.n > 2; free(t.d);
        if (!ok) { bp(o, "{\"error\":\"Invalid username or password\"}"); return 401; }
        snprintf(TOKEN, sizeof TOKEN, "%x%x", rand(), rand()); snprintf(extra, 200, "Set-Cookie: tok=%s; Path=/\r\n", TOKEN);
        bp(o, "{\"ok\":true}"); return 200;
    }
    if (!authed) { bp(o, "{\"error\":\"Not logged in\"}"); return 401; }
    if (!strcmp(path, "/api/logout")) { TOKEN[0] = 0; bp(o, "{\"ok\":true}"); return 200; }
    if (!strcmp(path, "/api/stats")) { qout(o, "SELECT (SELECT COUNT(*) FROM meters) total,(SELECT COUNT(*) FROM detections WHERE status='Normal') normal,(SELECT COUNT(*) FROM detections WHERE status!='Normal') suspicious,(SELECT COALESCE(SUM(consumption),0) FROM detections) consumption", 0, 0, 0); return 200; }
    if (!strcmp(path, "/api/chart")) { qout(o, "SELECT m month,SUM(c) kwh FROM (SELECT strftime('%Y-%m',read_date) m,reading-LAG(reading) OVER (PARTITION BY meter_id ORDER BY id) c FROM readings WHERE reading>=0) WHERE c>0 GROUP BY m ORDER BY m", 0, 0, 0); return 200; }
    if (!strcmp(path, "/api/meters") && !strcmp(meth, "GET")) {
        param(qs, "q", a, 100); param(qs, "f", b, 40); char like[140]; snprintf(like, 140, "%%%s%%", a);
        const char *bv[2] = {like, b};
        qout(o, "SELECT m.meter_id,m.consumer_id,d.prev_reading,d.curr_reading,d.consumption,d.status FROM meters m LEFT JOIN detections d ON d.meter_id=m.meter_id WHERE (m.meter_id LIKE ?1 OR m.consumer_id LIKE ?1) AND (?2='' OR d.status=?2) ORDER BY m.meter_id", 2, bv, 0); return 200;
    }
    if (!strcmp(path, "/api/meters")) {
        param(body, "meter", a, 64); param(body, "consumer", b, 64); param(body, "prev", c, 32); param(body, "curr", d, 32);
        if (!a[0] || !b[0] || !strlen(c) || !strlen(d) || atof(c) < 0 || atof(d) < 0 || strpbrk(a, "'\"")) { bp(o, "{\"error\":\"Fill all fields with valid values (readings >= 0)\"}"); return 400; }
        const char *mb[2] = {a, b}; xb("INSERT OR IGNORE INTO meters VALUES(?1,?2)", 2, mb);
        Buf t = {0}; const char *cb[1] = {a}; qout(&t, "SELECT 1 x FROM readings WHERE meter_id=?1", 1, cb, 0); int has = t.n > 2; free(t.d);
        if (!has) addreading(a, -1, atof(c));
        addreading(a, has ? 0 : 0, atof(d)); run_detection(); bp(o, "{\"ok\":true}"); return 200;
    }
    if (!strcmp(path, "/api/history")) { param(qs, "meter", a, 64); const char *bv[1] = {a}; qout(o, "SELECT read_date,reading FROM readings WHERE meter_id=?1 ORDER BY id", 1, bv, 0); return 200; }
    if (!strcmp(path, "/api/generate")) { generate_new(); run_detection(); bp(o, "{\"ok\":true}"); return 200; }
    if (!strcmp(path, "/api/reset")) { seed(1); run_detection(); bp(o, "{\"ok\":true}"); return 200; }
    if (!strcmp(path, "/api/detect") && !strcmp(meth, "POST")) {
        param(body, "threshold", a, 32); double t = atof(a) / 100.0; if (t < 0.05 || t > 0.95) { bp(o, "{\"error\":\"Threshold must be 5-95%\"}"); return 400; }
        THR = t; run_detection(); bp(o, "{\"ok\":true}"); return 200;
    }
    if (!strcmp(path, "/api/detections")) { qout(o, "SELECT * FROM detections ORDER BY CASE status WHEN 'Suspicious' THEN 0 WHEN 'Needs Inspection' THEN 1 ELSE 2 END,meter_id", 0, 0, 0); return 200; }
    if (!strcmp(path, "/api/threshold")) { bp(o, "{\"threshold\":%.0f}", THR * 100); return 200; }
    if (!strcmp(path, "/api/alerts") && !strcmp(meth, "GET")) { qout(o, "SELECT * FROM alerts ORDER BY id DESC", 0, 0, 0); return 200; }
    if (!strcmp(path, "/api/alert")) {
        param(body, "id", a, 32); param(body, "status", b, 32); param(body, "inspection", c, 32);
        const char *bv[3] = {a, b, c}; xb("UPDATE alerts SET status=?2,inspection=?3 WHERE id=?1", 3, bv); bp(o, "{\"ok\":true}"); return 200;
    }
    if (!strcmp(path, "/api/report")) {
        param(qs, "type", a, 32); *ct = "text/csv"; snprintf(extra, 200, "Content-Disposition: attachment; filename=%s_report.csv\r\n", a);
        if (!strcmp(a, "alerts")) qout(o, "SELECT * FROM alerts ORDER BY id", 0, 0, 1);
        else if (!strcmp(a, "consumption")) qout(o, "SELECT meter_id,read_date,reading FROM readings ORDER BY meter_id,id", 0, 0, 1);
        else qout(o, "SELECT * FROM detections ORDER BY meter_id", 0, 0, 1);
        return 200;
    }
    bp(o, "{\"error\":\"Not found\"}"); return 404;
}
static void reply(SOCKET c, int code, const char *ct, const char *body, size_t n, const char *extra) {
    char h[512]; int k = snprintf(h, sizeof h, "HTTP/1.1 %d X\r\nContent-Type: %s\r\nContent-Length: %lu\r\n%sConnection: close\r\n\r\n", code, ct, (unsigned long)n, extra);
    send(c, h, k, 0); size_t s = 0; while (s < n) { int r = send(c, body + s, (int)(n - s), 0); if (r <= 0) break; s += r; }
}
static void serve_file(SOCKET c, const char *path) {
    char fp[300], *ct = "text/html"; if (strstr(path, "..")) { reply(c, 404, "text/plain", "no", 2, ""); return; }
    snprintf(fp, sizeof fp, "../frontend%s", strcmp(path, "/") ? path : "/index.html");
    const char *e = strrchr(fp, '.'); if (e && !strcmp(e, ".css")) ct = "text/css"; else if (e && !strcmp(e, ".js")) ct = "application/javascript";
    FILE *f = fopen(fp, "rb"); if (!f) { reply(c, 404, "text/plain", "Not found", 9, ""); return; }
    fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f); char *d = malloc(n + 1); fread(d, 1, n, f); fclose(f);
    reply(c, 200, ct, d, n, ""); free(d);
}
static void handle(SOCKET c) {
    static char buf[16384]; int len = 0; buf[0] = 0;
    while (len < (int)sizeof buf - 1) {
        int r = recv(c, buf + len, sizeof buf - 1 - len, 0); if (r <= 0) break; len += r; buf[len] = 0;
        char *he = strstr(buf, "\r\n\r\n");
        if (he) { char low[2048]; int hl = (int)(he - buf); if (hl > 2047) hl = 2047; for (int i = 0; i < hl; i++) low[i] = tolower((unsigned char)buf[i]); low[hl] = 0;
            char *cl = strstr(low, "content-length:"); int need = cl ? atoi(cl + 15) : 0; if (len >= (int)(he - buf) + 4 + need) break; }
    }
    char meth[8], url[300]; if (sscanf(buf, "%7s %299s", meth, url) != 2) return;
    char *qs = strchr(url, '?'); if (qs) *qs++ = 0; else qs = "";
    char *body = strstr(buf, "\r\n\r\n"); body = body ? body + 4 : "";
    char hdr[2048]; int hl = body - buf > 2047 ? 2047 : (int)(body - buf); memcpy(hdr, buf, hl); hdr[hl] = 0;
    char want[64]; snprintf(want, 64, "tok=%s", TOKEN); int authed = TOKEN[0] && strstr(hdr, want);
    if (strncmp(url, "/api/", 5)) { serve_file(c, url); return; }
    Buf o = {0}; const char *ct; char extra[256] = ""; int code = api(meth, url, qs, body, &o, &ct, extra, authed);
    reply(c, code, ct, o.d ? o.d : "", o.n, extra); free(o.d);
}
int main(void) {
#ifdef _WIN32
    WSADATA w; WSAStartup(MAKEWORD(2, 2), &w);
#endif
    if (sqlite3_open("../database/theft.db", &db)) { printf("Cannot open database\n"); return 1; }
    FILE *f = fopen("../database/schema.sql", "rb"); if (!f) { printf("schema.sql not found (run from backend folder)\n"); return 1; }
    char sch[4096]; size_t n = fread(sch, 1, sizeof sch - 1, f); sch[n] = 0; fclose(f);
    sqlite3_exec(db, sch, 0, 0, 0);
    sqlite3_stmt *s; sqlite3_prepare_v2(db, "SELECT COUNT(*) FROM meters", -1, &s, 0); sqlite3_step(s); int cnt = sqlite3_column_int(s, 0); sqlite3_finalize(s);
    if (!cnt) seed(0); run_detection(); srand((unsigned)time(0));
    SOCKET srv = socket(AF_INET, SOCK_STREAM, 0); int on = 1; setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, (const char *)&on, sizeof on);
    struct sockaddr_in ad = {0}; ad.sin_family = AF_INET; ad.sin_port = htons(PORT); ad.sin_addr.s_addr = htonl(0x7F000001);
    if (bind(srv, (struct sockaddr *)&ad, sizeof ad) || listen(srv, 8)) { printf("Port %d busy\n", PORT); return 1; }
    printf("Server running: http://localhost:%d  (login admin / admin123)\n", PORT);
    for (;;) { SOCKET c = accept(srv, 0, 0); if (c < 0) continue; handle(c); closesocket(c); }
}
