#ifndef DETECTION_H
#define DETECTION_H
typedef struct { double cons, avg; char status[24]; char reason[200]; } Result;
/* prev/curr = meter readings (negative = missing); hist = past monthly consumptions; thr = deviation threshold (0.4 = 40%) */
void analyze(double prev, double curr, const double *hist, int n, double thr, Result *r);
#endif
