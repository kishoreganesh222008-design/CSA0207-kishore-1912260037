#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "detection.h"
static void set(Result *r, const char *st, const char *fmt, ...) {
    va_list a; snprintf(r->status, sizeof r->status, "%s", st);
    va_start(a, fmt); vsnprintf(r->reason, sizeof r->reason, fmt, a); va_end(a);
}
void analyze(double prev, double curr, const double *h, int n, double thr, Result *r) {
    memset(r, 0, sizeof *r);
    double s = 0; for (int i = 0; i < n; i++) s += h[i];
    r->avg = n ? s / n : 0;
    if (curr < 0) { set(r, "Needs Inspection", "Current reading is missing. Manual inspection required."); return; }
    if (prev < 0) { set(r, "Needs Inspection", "No previous reading available to compare."); return; }
    r->cons = curr - prev;
    if (r->cons < 0) { set(r, "Needs Inspection", "Current reading (%.0f) is lower than previous (%.0f): inconsistent or tampered meter. Inspect.", curr, prev); return; }
    if (n == 0) { r->avg = r->cons; set(r, "Normal", "Not enough history; %.0f kWh used.", r->cons); return; }
    if (r->cons == 0 && r->avg > 0) { set(r, "Needs Inspection", "Zero consumption although historical average is %.0f kWh. Inspect.", r->avg); return; }
    double dev = r->avg > 0 ? (r->cons - r->avg) / r->avg : 0;
    if (dev < -thr) { set(r, "Suspicious", "Consumption %.0f%% below historical average. Possible tampering; needs human inspection.", -dev * 100); return; }
    if (dev > 2 * thr) { set(r, "Needs Inspection", "Consumption %.0f%% above historical average. Unusual spike; verify on site.", dev * 100); return; }
    set(r, "Normal", "Within %.0f%% threshold of historical average.", thr * 100);
}
